import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ListingCreate extends StatefulWidget {
  const ListingCreate({super.key});
  @override
  State<ListingCreate> createState() => _ListingCreateState();
}

class _ListingCreateState extends State<ListingCreate> {
  String title = '';
  String desc = '';
  double price = 0;
  bool loading = false;

  Future<void> submit() async {
    setState(()=>loading=true);
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى تسجيل الدخول')));
      setState(()=>loading=false);
      return;
    }
    await FirebaseFirestore.instance.collection('listings').add({
      'title': title,
      'description': desc,
      'price': price,
      'ownerId': user.uid,
      'isProduct': false,
      'createdAt': FieldValue.serverTimestamp(),
      'visible': true,
    });
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إنشاء عرض')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          TextField(decoration: const InputDecoration(labelText: 'العنوان'), onChanged: (v)=>title=v),
          TextField(decoration: const InputDecoration(labelText: 'الوصف'), onChanged: (v)=>desc=v),
          TextField(decoration: const InputDecoration(labelText: 'السعر'), keyboardType: TextInputType.number, onChanged: (v)=>price=double.tryParse(v)??0),
          const SizedBox(height:12),
          ElevatedButton(onPressed: loading?null: submit, child: loading? const CircularProgressIndicator(): const Text('نشر')),
        ]),
      ),
    );
  }
}
