import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../ratings/rating_widget.dart';

class ListingDetail extends StatefulWidget {
  const ListingDetail({super.key});
  @override
  State<ListingDetail> createState() => _ListingDetailState();
}

class _ListingDetailState extends State<ListingDetail> {
  Map<String,dynamic>? listing;
  String listingId = '';
  bool loading = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments as Map<String,dynamic>?;
    if (args != null) {
      listing = args['listing'];
      listingId = args['id'] ?? '';
    }
  }

  Future<void> placeOrder() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى تسجيل الدخول')));
      return;
    }
    setState(()=>loading=true);
    // fetch fee percent from settings doc
    final settingsDoc = await FirebaseFirestore.instance.collection('settings').doc('app').get();
    double feePercent = 5;
    if (settingsDoc.exists) {
      final data = settingsDoc.data()!;
      feePercent = (data['feePercent'] ?? 5).toDouble();
    }
    final price = (listing?['price'] ?? 0).toDouble();
    final fee = (feePercent/100)*price;
    final orderRef = await FirebaseFirestore.instance.collection('orders').add({
      'listingId': listingId,
      'buyerId': user.uid,
      'ownerId': listing?['ownerId'],
      'total': price,
      'fee': fee,
      'paymentMethod': 'COD',
      'paymentStatus': 'pending-cash',
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    setState(()=>loading=false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إنشاء الطلب')));
    Navigator.of(context).pushReplacementNamed('/orders');
  }

  void submitRating(double rating, String comment) async {
    if (listingId.isEmpty) return;
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await FirebaseFirestore.instance.collection('ratings').add({
      'listingId': listingId,
      'userId': user.uid,
      'rating': rating,
      'comment': comment,
      'createdAt': FieldValue.serverTimestamp(),
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال التقييم')));
  }

  @override
  Widget build(BuildContext context) {
    if (listing == null) return const Scaffold(body: Center(child: Text('العرض غير متوفر')));
    return Scaffold(
      appBar: AppBar(title: Text(listing?['title'] ?? '')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          Text(listing?['description'] ?? ''),
          const SizedBox(height: 12),
          Text('السعر: ${listing?['price'] ?? 0} DA'),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: loading?null: placeOrder, child: loading? const CircularProgressIndicator(): const Text('اطلب الخدمة')),
          const SizedBox(height: 20),
          const Text('قَيِّم هذا العرض'),
          RatingWidget(onSubmit: submitRating),
        ]),
      ),
    );
  }
}
