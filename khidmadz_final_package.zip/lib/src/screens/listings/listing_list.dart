import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ListingList extends StatelessWidget {
  const ListingList({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('العروض')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('listings').orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (c, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              return ListTile(
                title: Text(d['title'] ?? ''),
                subtitle: Text(d['description'] ?? ''),
                trailing: Text('${d['price'] ?? 0} DA'),
                onTap: () {
                  Navigator.of(context).pushNamed('/listing_detail', arguments: {'id': docs[i].id, 'listing': d});
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => Navigator.of(context).pushNamed('/create_listing'),
      ),
    );
  }
}
