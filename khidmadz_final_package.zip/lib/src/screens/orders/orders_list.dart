import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class OrdersList extends StatelessWidget {
  const OrdersList({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('الطلبات')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('orders').orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (c, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final id = docs[i].id;
              return ListTile(
                title: Text('Order ${id}'),
                subtitle: Text('Status: ${d['status'] ?? 'pending'} - Payment: ${d['paymentMethod'] ?? 'COD'}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  if (user != null && user.uid == d['ownerId']) IconButton(icon: const Icon(Icons.check), onPressed: () => FirebaseFirestore.instance.collection('orders').doc(id).update({'status':'accepted'})),
                  if (user != null && (user.uid == d['ownerId'] || user.uid == d['buyerId'])) IconButton(icon: const Icon(Icons.done), onPressed: () => FirebaseFirestore.instance.collection('orders').doc(id).update({'status':'completed'})),
                ]),
              );
            },
          );
        },
      ),
    );
  }
}
