import 'package:flutter/material.dart';
class CustomerDashboard extends StatelessWidget {
  const CustomerDashboard({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة الزبون')),
      body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ElevatedButton(onPressed: ()=>Navigator.of(context).pushNamed('/listings'), child: const Text('تصفح العروض')),
        ElevatedButton(onPressed: ()=>Navigator.of(context).pushNamed('/orders'), child: const Text('طلباتي')),
      ])),
    );
  }
}
