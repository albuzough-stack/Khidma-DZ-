import 'package:flutter/material.dart';
class ProviderDashboard extends StatelessWidget {
  const ProviderDashboard({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة المزوّد')),
      body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ElevatedButton(onPressed: ()=>Navigator.of(context).pushNamed('/create_listing'), child: const Text('انشر خدمة')),
        ElevatedButton(onPressed: ()=>Navigator.of(context).pushNamed('/orders'), child: const Text('طلبات')),
      ])),
    );
  }
}
