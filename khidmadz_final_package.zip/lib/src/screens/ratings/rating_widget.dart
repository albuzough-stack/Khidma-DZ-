import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class RatingWidget extends StatelessWidget {
  final Function(double, String) onSubmit;
  const RatingWidget({super.key, required this.onSubmit});
  @override
  Widget build(BuildContext context) {
    double rating = 5;
    String comment = '';
    return Column(children: [
      RatingBar.builder(
        initialRating: 5,
        minRating: 1,
        direction: Axis.horizontal,
        allowHalfRating: true,
        itemCount: 5,
        itemBuilder: (context, _) => const Icon(Icons.star, color: Colors.amber),
        onRatingUpdate: (r) => rating = r,
      ),
      TextField(decoration: const InputDecoration(labelText: 'تعليق'), onChanged: (v)=>comment=v),
      ElevatedButton(onPressed: ()=>onSubmit(rating, comment), child: const Text('أرسل تقييم')),
    ]);
  }
}
