import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminPanel extends StatefulWidget {
  const AdminPanel({super.key});
  @override
  State<AdminPanel> createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  final _fire = FirebaseFirestore.instance;
  double fee = 5;
  @override
  void initState() {
    super.initState();
    _loadSettings();
  }
  void _loadSettings() async {
    final doc = await _fire.collection('settings').doc('app').get();
    if (doc.exists) setState(()=>fee = (doc.data()?['feePercent'] ?? 5).toDouble());
  }
  void _save() async {
    await _fire.collection('settings').doc('app').set({'feePercent': fee});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الإعدادات')));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة الإدارة')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12.0), child: Row(children: [
          const Text('نسبة العمولة %:'),
          const SizedBox(width: 12),
          Expanded(child: Slider(value: fee, min: 0, max: 20, divisions: 20, label: '${fee.round()}', onChanged: (v)=>setState(()=>fee=v))),
          ElevatedButton(onPressed: _save, child: const Text('حفظ')),
        ])),
        const Divider(),
        Expanded(child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('users').snapshots(),
          builder: (context, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs;
            return ListView.builder(itemCount: docs.length, itemBuilder: (c, i) {
              final d = docs[i].data() as Map<String,dynamic>;
              final uid = docs[i].id;
              return ListTile(
                title: Text(d['name'] ?? d['email'] ?? uid),
                subtitle: Text('role: ${d['role'] ?? 'n/a'} - verified: ${d['verified'] ?? false}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(icon: const Icon(Icons.check), onPressed: () => FirebaseFirestore.instance.collection('users').doc(uid).update({'verified': true})),
                  IconButton(icon: const Icon(Icons.close), onPressed: () => FirebaseFirestore.instance.collection('users').doc(uid).update({'verified': false})),
                ]),
              );
            });
          },
        ))
      ],),
    );
  }
}
