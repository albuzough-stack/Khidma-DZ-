import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _auth = FirebaseAuth.instance;
  final _fire = FirebaseFirestore.instance;
  final _storage = FirebaseStorage.instance;
  final _picker = ImagePicker();

  String email = '';
  String password = '';
  String phone = '';
  String name = '';
  String accountType = 'provider'; // provider | customer | admin
  File? idImage;
  bool loading = false;

  Future pickIdImage() async {
    final XFile? file = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (file == null) return;
    setState(() => idImage = File(file.path));
  }

  Future<Map<String,dynamic>?> _uploadIdAndOCR(String uid) async {
    if (idImage == null) return null;
    final ref = _storage.ref().child('ids/$uid/${DateTime.now().millisecondsSinceEpoch}.jpg');
    await ref.putFile(idImage!);
    final url = await ref.getDownloadURL();

    final inputImage = InputImage.fromFile(idImage!);
    final recognizer = TextRecognizer(script: TextRecognitionScript.arabic);
    final result = await recognizer.processImage(inputImage);
    await recognizer.close();

    return {'url': url, 'ocr': result.text};
  }

  Future<void> registerWithEmail() async {
    setState(()=>loading=true);
    try {
      final cred = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      final uid = cred.user!.uid;
      final info = await _uploadIdAndOCR(uid);
      await _fire.collection('users').doc(uid).set({
        'uid': uid,
        'name': name,
        'email': email,
        'phone': phone,
        'role': accountType,
        'verified': info != null,
        'idUrl': info?['url'],
        'ocr': info?['ocr'],
        'createdAt': FieldValue.serverTimestamp()
      });
      final snap = await _fire.collection('users').get();
      if (snap.docs.length == 1) {
        await _fire.collection('users').doc(uid).update({'role':'admin','isAdmin':true});
      }
      Navigator.of(context).pushReplacementNamed(accountType=='provider' ? '/provider_dashboard' : '/customer_dashboard');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      setState(()=>loading=false);
    }
  }

  Future<void> signInWithGoogle() async {
    setState(()=>loading=true);
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) return;
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(idToken: googleAuth.idToken, accessToken: googleAuth.accessToken);
      final userCred = await _auth.signInWithCredential(credential);
      final uid = userCred.user!.uid;

      final docRef = _fire.collection('users').doc(uid);
      final docSnap = await docRef.get();
      if (!docSnap.exists) {
        await docRef.set({
          'uid': uid,
          'name': userCred.user?.displayName ?? '',
          'email': userCred.user?.email ?? '',
          'phone': userCred.user?.phoneNumber ?? '',
          'role': accountType,
          'verified': false,
          'createdAt': FieldValue.serverTimestamp()
        });
      }
      Navigator.of(context).pushReplacementNamed(accountType=='provider' ? '/provider_dashboard' : '/customer_dashboard');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      setState(()=>loading=false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل / S\'inscrire')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Image.asset('assets/logo1.png', width: 100),
          const SizedBox(height: 8),
          TextField(decoration: const InputDecoration(labelText: 'الاسم / Nom'), onChanged: (v)=>name=v),
          TextField(decoration: const InputDecoration(labelText: 'البريد الإلكتروني / Email'), onChanged: (v)=>email=v),
          TextField(decoration: const InputDecoration(labelText: 'كلمة المرور / Mot de passe'), obscureText: true, onChanged: (v)=>password=v),
          TextField(decoration: const InputDecoration(labelText: 'الهاتف / Téléphone'), onChanged: (v)=>phone=v),
          const SizedBox(height: 8),
          Row(children: [
            const Text('نوع الحساب:'),
            const SizedBox(width: 12),
            DropdownButton<String>(
              value: accountType,
              items: const [
                DropdownMenuItem(value: 'provider', child: Text('مزود خدمة / Prestataire')),
                DropdownMenuItem(value: 'customer', child: Text('زبون / Client')),
                DropdownMenuItem(value: 'admin', child: Text('إدارة / Admin')),
              ],
              onChanged: (v){ if (v!=null) setState(()=>accountType=v); },
            )
          ]),
          const SizedBox(height: 12),
          ElevatedButton.icon(onPressed: pickIdImage, icon: const Icon(Icons.upload_file), label: const Text('رفع بطاقة الهوية / Télécharger CIN')),
          if (idImage != null) Padding(padding: const EdgeInsets.only(top:8.0), child: Image.file(idImage!, height: 120)),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: registerWithEmail, child: loading ? const CircularProgressIndicator() : const Text('سجل (Email)')),
          const SizedBox(height: 8),
          ElevatedButton.icon(onPressed: signInWithGoogle, icon: const Icon(Icons.login), label: const Text('سجل بواسطة Google')),
        ]),
      ),
    );
  }
}
