import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/choose_lang.dart';
import 'screens/home_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/customer/customer_dashboard.dart';
import 'screens/provider/provider_dashboard.dart';
import 'screens/admin/admin_panel.dart';
import 'screens/listings/listing_list.dart';
import 'screens/listings/listing_create.dart';
import 'screens/listings/listing_detail.dart';
import 'screens/orders/orders_list.dart';

class KhidmaApp extends StatelessWidget {
  const KhidmaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Khidma DZ',
      theme: ThemeData(
        primaryColor: const Color(0xFF1E3A8A),
        scaffoldBackgroundColor: const Color(0xFFF7F7FB),
        colorScheme: ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFF6B7280)),
        fontFamily: 'Roboto',
      ),
      initialRoute: '/splash',
      routes: {
        '/splash': (c) => const SplashScreen(),
        '/chooseLang': (c) => const ChooseLangScreen(),
        '/': (c) => const HomeScreen(),
        '/register': (c) => const RegisterScreen(),
        '/login': (c) => const LoginScreen(),
        '/customer_dashboard': (c) => const CustomerDashboard(),
        '/provider_dashboard': (c) => const ProviderDashboard(),
        '/admin_panel': (c) => const AdminPanel(),
        '/listings': (c) => const ListingList(),
        '/create_listing': (c) => const ListingCreate(),
        '/listing_detail': (c) => const ListingDetail(),
        '/orders': (c) => const OrdersList(),
      },
    );
  }
}
