Khidma DZ - Final Flutter package (Orders, Ratings, Admin)
---------------------------------------------------------

This final package adds completed Orders flow, Ratings persistence, and Admin settings (feePercent).
What's included now:
- Place orders from Listing Detail (COD by default) with automatic fee calculation (settings.app.feePercent)
- Orders list where providers/admin can accept/complete orders
- Ratings saved to 'ratings' collection
- Admin panel to change feePercent and verify users
- ECCP mock server provided in server/eccp-server.js
- Firebase rules sample included

How to run:
1) Unzip and open project
2) flutter pub get
3) Configure Firebase (Auth providers, Firestore, Storage)
4) Add google-services.json to android/app and configure firebase_options.dart
5) Run: flutter run
6) Build release: flutter build appbundle --release

Notes & next steps:
- Integrate ECCP real API when credentials are available.
- Add phone OTP auth if desired.
- Improve UI/UX and translations (currently simple labels).
- Tighten Firestore & Storage security rules before production.
